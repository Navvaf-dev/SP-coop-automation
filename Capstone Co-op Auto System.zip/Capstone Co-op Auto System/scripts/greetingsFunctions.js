// Function for Student button (empty for now)
function handleStudent() {
    alert("Student section is under construction.");
}

// Function for Advisor button (empty for now)
function handleAdvisor() {
    alert("Advisor section is under construction.");
}